/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Chatur Veda Vyas Kurma;
 */
public class Person 
{
 private String firstName;
    private String lastName;
    private Dog[] pets = new Dog[5];

    //end of attribute decleration
    /**
     *
     * @param firstName String Attribute
     * @param lastName String Attribute
     * @param pets Array of Dog object
     */
    public Person(String firstName, String lastName, Dog[] pets) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.pets = pets;
    }//end of all parameter constructor

    /**
     *
     * @return String First Name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     *
     * @return String Last Name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     *
     * @return Array of Dog object
     */
    public Dog[] getPets() {
        return pets;
    }

    /**
     *
     * @param newPet Dog object
     */
    public void addNewPet(Dog newPet) {

        if (pets[0] == null) {
            pets[0] = newPet;
        } else {
            Dog[] pets1 = new Dog[pets.length + 1];
            for (int i = 0; i < pets.length; i++) {
                pets1[i + 1] = pets[i];

            }//loop for copying into temperory array of Dpg

            pets = new Dog[pets.length + 1];//increasing size of pets array

            for (int i = 0; i < pets.length; i++) {
                pets[i] = pets1[i];

            }//copying from temperory array to pets array

            //pets[pets.length-1] = pets[0];
            pets[0] = newPet;
        }//end of else condition

    }  //end of addNewPet method

    /**
     *
     * @param petName String Attribute
     * @return Dog object
     */
    public Dog removePet(String petName) {
        Dog remove = null;
        Dog last = null;
        for (int i = 0; i < pets.length; i++) {
            if (pets[i].getName().equals(petName)) {
                last = pets[pets.length - 1];
                remove = pets[i];
                pets[i] = last;
                pets[pets.length - 1] = remove;
            }
        }//end of for loop 1

        Dog[] pets1 = new Dog[pets.length];
        for (int j = 0; j < pets1.length; j++) {
            pets1[j] = pets[j];

        }//end of for loop 2

        pets = new Dog[pets1.length - 1];

        for (int i = 0; i < pets.length; i++) {
            pets[i] = pets1[i];

        }//end of for loop 3

        return remove;
    } //end of removePet method

    /**
     *
     * @return Dog object
     * @throws ParseException
     */
    public Dog getYoungest() throws ParseException {
        Dog youngest = null;

        ArrayList<Integer> al = new ArrayList<Integer>();

        for (int i = 0; i < pets.length; i++) {
            al.add(getAge(pets[i].getDob()));
        }//loop for getting all dog ages and assigning it in a arraylist

        //array list have all age of dogs
        int young = al.get(0);//setting temerory young variable

        for (int i = 0; i < al.size(); i++) {
            if (young > al.get(i)) {
                young = al.get(i);
            }//swaping young dog with current dog

        }//loop to get youngest of all dogs

        for (int i = 0; i < pets.length; i++) {
            if (young == getAge(pets[i].getDob())) {
                youngest = pets[i];
            }

        }//loop for getting all details of youngest dog

        return youngest;
    }//end of getYoungest method

    /**
     *
     * @param date String Attribute
     * @return Integer age
     * @throws ParseException
     */
    public int getAge(String date) throws ParseException {

        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
        Date date1 = new Date();
        String date2 = format.format(date1);

        Date d1;
        Date d2;

        d1 = format.parse(date);
        d2 = format.parse(date2);

        long difference = d2.getTime() - d1.getTime();

        int days = (int) TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS);
        return days;
    } //end of getAge method

    @Override
    public String toString() {
        //System.out.println("**************************************");
        String a = ("Owner: " + lastName + ", " + firstName + "\r\n");
        String b = ("Pets:\r\n");
        String c = ("*************************\r\n");

        String d = "";
        for (int i = 0; i < pets.length - 1; i++) {
            d = d + (pets[i].toString() + "\r\n--------------------------------------\r\n");
        }//end of for loop

        d = d + ( pets[pets.length - 1].toString() + "\r\n");

       

        return a + b + c + d ;

    }//end of toString method

}//end of class
