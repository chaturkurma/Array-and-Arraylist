/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Chatur Veda Vyas Kurma;
 */
public class PetDriver {
     public static void main(String[] args) throws FileNotFoundException, ParseException {

        System.out.println("**************************************");
        System.out.println("Printing all person objects");
        System.out.println("**************************************");

        // 1.Declare and initialize a scanner object to read from the file "inputFile1.txt"
        Scanner file1 = new Scanner(new File("inputFile1.txt"));

        // 2.Declare and initialize a PrintWriter object to write output to the file "outputFileText1.txt"
        PrintWriter output = new PrintWriter(new File("outputFileText1.txt"));

        //writing in output file
        output.write("**************************************\r\n");
        output.write("Printing all person objects\r\n");
        output.write("**************************************\r\n");
        //end of writing in output file

        // 3.Create an ArrayList of Person objects with name "persons"
        ArrayList<Person> persons = new ArrayList<Person>();

        // 4.While inputFile1.txt has more data(While loop starts here) 
        while (file1.hasNext()) {   //Read in the data

            // 6.Read firstName and lastName of the person.
            String firstName = file1.next();
            String lastName = file1.next();
            file1.nextLine();

            // 7.Read number of dogs owned by a person. 
            int noOfDogs = file1.nextInt();
            file1.nextLine();

            // 8.Create a Dog array and name it as pets and initialize with size equal to number of dogs the person own.
            Dog[] pets = new Dog[noOfDogs];

            // 9.For number of dogs a person own, read breed, age, weight and name of a dog.
            for (int i = 0; i < noOfDogs; i++) {
                String breed = file1.nextLine();
                String dob = file1.next();
                float weight = file1.nextFloat();
                file1.nextLine();
                String dogName = file1.nextLine();
                // 10.Create an instance of Dog and initialize with above scanned attributes.
                Dog dog = new Dog(dogName, breed, dob, weight);

                // 11.Add all Dogs of a person to pets.
                pets[i] = dog;

            }//loop for running no of dogs per owner

            // 12.Create an instance of Person and initialize with above attributes. Add this person instance to persons ArrayList
            Person person = new Person(firstName, lastName, pets);
            //
            //person.addNewPet(add);
            persons.add(person);
            // person.toString();

        }//end of while loop

        Dog add = new Dog("Grey Wind", "Alaskan Malamute", "04/15/2009", (float) 83.5);

        Person first = persons.get(0);
        first.addNewPet(add);

        Person second = persons.get(1);
        second.removePet("Grey Wind");
        for (int i = 0; i < persons.size(); i++) {
            Person p = persons.get(i);
            System.out.println(p.toString()); // writing on console using toString method
            System.out.println("--------------------------------------");
            System.out.println("**************************************");

            output.write(p.toString());//writing to output file using toString method
            output.write("--------------------------------------");
            output.write("**************************************\r\n");
        }//loop for printing all dogs using ArrayList

        System.out.println("*******Testing getYougest() method************");
        System.out.println("************************************************");

        output.write("*******Testing getYougest() method************\r\n");

        for (int i = 0; i < persons.size(); i++) {
            Person p = persons.get(i);
            Dog d = p.getYoungest();
            System.out.println(d.getName() + " is the youngest pet dog of " + p.getFirstName() + " " + p.getLastName() + ".");

            output.write(d.getName() + " is the youngest pet dog of " + p.getFirstName() + " " + p.getLastName() + ".\r\n");

        }//end of for loop

        System.out.println("**************************************");

        output.write("**************************************\r\n");

        output.close();
    }//end of main method
    
    
}//end of the class
