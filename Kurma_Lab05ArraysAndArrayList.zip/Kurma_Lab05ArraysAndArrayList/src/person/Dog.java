/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author Chatur Veda Vyas Kurma;
 */
public class Dog 
{
 private String name, breed, dob;
    private float weight;

    public Dog(String name, String breed, String dob, float weight) {
        this.name = name;
        this.breed = breed;
        this.dob = dob;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public String getBreed() {
        return breed;
    }

    public String getDob() {
        return dob;
    }

    public float getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return "Name: " + name + "\n" + "Breed: " + breed + "\n" + "DoB: " + dob + ", Weight: " + weight + " lbs";
    }
}

