/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Chatur Veda Vyas Kurma;
 */
public class SalesDriver {

  /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

        //1.Declare and initialize a Scanner object to read from the file "inputFile2.txt"
        Scanner file2 = new Scanner(new File("inputFile2.txt"));

        //2.Declare and initialize a PrintWriter object to write output to the file "outputFileText2.txt"
        PrintWriter output = new PrintWriter(new File("outputFileText2.txt"));

        //3.create an ArrayList of Retailer objects with name "retailers"
        ArrayList<Retailer> retailers = new ArrayList<Retailer>();

        //4.Read Data
        String retail = file2.nextLine();

        while (file2.hasNext()) { //Read line
            //5.Read Retailer name and address
            String name = file2.nextLine();
            String address = file2.nextLine();

            //6.Declare and initialize an object for retailer using above read values
            Retailer retailer = new Retailer(name, address);

            //7.Read all beers available for the retailer. Loop starts here
            do {
                // 8.Read all details of a beer
                if (!file2.hasNext()) {
                    break;
                }//end of if statement

                String beerName = file2.nextLine();
                if (beerName.equals("Retailer")) {
                    break;
                }//end of if statement
                String beerStyle = file2.nextLine();
                String beerType = file2.next();
                double abv = file2.nextDouble();
                file2.nextLine();
                String availeblePackages = file2.nextLine();

                String[] a = availeblePackages.split(" ");
                int[] b = new int[a.length];
                for (int i = 0; i < a.length; i++) {
                    b[i] = Integer.parseInt(a[i]);
                }//end of for loop 

                // 9.Declare and initialize an object for Beer using above read values
                Beer beer = new Beer(beerName, beerType, beerStyle, abv, b);

                // 10.Add the declared beer object to retailer object created in the outer loop
                retailer.addNewBeer(beer);

            } while (retail.equals("Retailer")); //End the loop if reading all the Beer objects for a retailer is completed
            // 11.Add the retailer object created in this loop to variable retailers
            retailers.add(retailer);

        }//end of while loop

        /*!!!For bellow statements, use loops to retrive required Retailer object from arraylist "retailers"
             Do not hardcode indexes to retrive data from variable retailers*/
        // 12.Print "******Walmart Inventory for Beer's*****"
        System.out.println("***************************************");
        System.out.println("******Walmart Inventory for Beer's*****");
        System.out.println("***************************************");

        //printing in an output file
        output.write("***************************************\r\n");
        output.write("******Walmart Inventory for Beer's*****\r\n");
        output.write("***************************************\r\n");

        // 13.Invoke toString() on retailer "Walmart" and print object
        for (int i = 0; i < retailers.size(); i++) {
            if (retailers.get(i).getRetailerName().equals("Walmart")) {
                System.out.println(retailers.get(i).toString()); //printing to console using toString method               
                output.write(retailers.get(i).toString() + "\r\n");//printing to the output file

            }//end of if statement

        }//end of for loop
        //end of getting details of retailer

        // 14.Print "******Remove Wells IP from Walmart*****"
        System.out.println("***********************************");
        System.out.println("******Remove Bass from Walmart*****");
        System.out.println("***********************************");

        output.write("***********************************\r\n");
        output.write("******Remove Bass from Walmart*****\r\n");
        output.write("***********************************\r\n");

        Beer remove = null;
        for (int i = 0; i < retailers.size(); i++) {
            if (retailers.get(i).getRetailerName().equals("Walmart")) {
                remove = retailers.get(i).removeBeer("Wells IPA");
            }//end of if statement

        }//end of for loop
        //end of removing a beerName from retailer walmart

        // 15.Remove Beer with name "Wells IP" from retailer "Walmart" in retailers and print removed beer details.
        System.out.println(remove.toString());//printing to console using toSring method

        output.write(remove.toString() + "\r\n");//printing to output file

        // 16.Print "****List of strong beer from Hy-Vee****"
        System.out.println("***************************************");
        System.out.println("****List of strong beer from Hy-Vee****");
        System.out.println("***************************************");

        output.write("***************************************\r\n");
        output.write("****List of strong beer from Hy-Vee****\r\n");
        output.write("***************************************\r\n");

        // 17.Print all strong beer available in Hy-Vee
        ArrayList<Beer> a = null;
        for (int i = 0; i < retailers.size(); i++) {
            if (retailers.get(i).getRetailerName().equals("Hy-Vee")) {
                a = retailers.get(i).getStrongBeers();
            }//end of if statement

        }//end of for loop
        for (int i = 0; i < a.size(); i++) {
            System.out.println(a.get(i).toString()+"--------------------");//printing using toString method

            output.write(a.get(i).toString() + "\r--------------------\n");//printing to output file using toString method

        }//end of for loop for printing all strong beer

        // 18.Print "****List of light beer from Sam's Club****"
        System.out.println("******************************************");
        System.out.println("****List of light beer from Sam's Club****");
        System.out.println("******************************************");

        output.write("******************************************\r\n");
        output.write("****List of light beer from Sam's Club****\r\n");
        output.write("******************************************\r\n");

        // 19.Print all light beer available in Sam's Club
        ArrayList<Beer> sam = null;
        for (int i = 0; i < retailers.size(); i++) {
            if (retailers.get(i).getRetailerName().equals("Sam's Club")) {
                sam = retailers.get(i).getLightBeers();
            }//end of if statement

        }//end of for loop
        for (int i = 0; i < sam.size(); i++) {
            System.out.println(sam.get(i).toString()+"--------------------");//printing to console using toString method

            output.write(sam.get(i).toString() + "\r--------------------\n");//printing to output file using toString method

        }//end of for loop for printing all light beer from sams club

        // 20.Print  "****Count of different beers available from each retailer****"
        System.out.println("*************************************************************");
        System.out.println("****Count of different beers available from each retailer****");
        System.out.println("*************************************************************");

        output.write("*************************************************************\r\n");
        output.write("****Count of different beers available from each retailer****\r\n");
        output.write("*************************************************************\r\n");

        // 21.Print count of different beers available from each retailer
        for (int i = 0; i < retailers.size(); i++) {
            System.out.println(retailers.get(i).getRetailerName() + ": " + retailers.get(i).getBeerList().size());//printing to console

            output.write(retailers.get(i).getRetailerName() + ": " + retailers.get(i).getBeerList().size() + "\r\n");//printing to output file

        }//end of for loop for counting no of beers availeble for each retailer
        System.out.println();
        output.write("\r\n");
        // 22.Print "****All different beers available from all retailers****"
        System.out.println("********************************************************");
        System.out.println("****All different beers available from all retailers****");
        System.out.println("********************************************************");

        output.write("********************************************************\r\n");
        output.write("****All different beers available from all retailers****\r\n");
        output.write("********************************************************\r\n");

        // 23.Print Names of all different beers from all retailers
        ArrayList<String> beerName = new ArrayList<String>();
        for (int i = 0; i < retailers.size(); i++) {

            ArrayList<Beer> beer = retailers.get(i).getBeerList();
            for (int j = 0; j < retailers.get(i).getBeerList().size(); j++) {
                beerName.add(beer.get(j).getBeerName());
            }
        }//end of for loop

        for (int i = 0; i < beerName.size(); i++) {
            for (int j = i + 1; j < beerName.size(); j++) {
                if (beerName.get(i).equals(beerName.get(j))) {
                    beerName.remove(j);
                    j--;
                }// end of if statement
            }//end of inner loop
        }//end of outer loop

        for (int i = 0; i < beerName.size(); i++) {
            System.out.println(beerName.get(i));//printing to console

            output.write(beerName.get(i) + "\r\n");//printing to output file 

        }//end of for loop

        System.out.println("********************************************************");
        output.write("********************************************************");
        // 24.Close PrintWriter object
        output.close();

    }//end of main method

}//end of class
