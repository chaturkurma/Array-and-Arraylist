/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beer;

import java.util.ArrayList;

/**
 *
 * @author Chatur Veda Vyas Kurma;
 */
public class Retailer 
{
 //declering private instance variables

    private String retailerName;
    private String address;
    private ArrayList<Beer> beerList;

    /**
     *
     * @param retailerName String Attribute
     * @param address String Attribute
     */
    public Retailer(String retailerName, String address) {
        this.retailerName = retailerName;
        this.address = address;
        beerList = new ArrayList<Beer>();
    }//end of constructor

    //start of getter methods
    /**
     *
     * @return String Attribute
     */
    public String getRetailerName() {
        return retailerName;
    }

    /**
     *
     * @return String Attribute
     */
    public String getAddress() {
        return address;
    }

    /**
     *
     * @return ArrayList
     */
    public ArrayList<Beer> getBeerList() {
        return beerList;
    }

    //end of getter methods
    /**
     *
     * @param beerName String Attribute
     * @return boolean value a
     */
    public boolean isAvailable(String beerName) {

        boolean a = false;

        for (int i = 0; i < beerList.size(); i++) {
            Beer b = beerList.get(i);
            if (b.getBeerName().equals(beerName)) {
                a = true;
            }

        }//end of for loop

        return a;
    }//end of isAvailable method

    /**
     *
     * @param newBeer Beer object
     */
    public void addNewBeer(Beer newBeer) {

        int count = 0;
        if (beerList.size() == 0) {
            beerList.add(newBeer);
        } else {
            for (int i = 0; i < beerList.size(); i++) {
                if (beerList.get(i).equals(newBeer)) {
                    count = 1;
                }

            }//end of loop
            if (count != 1) {
                beerList.add(newBeer);
            }
        }

    }//end of addNewBeer method

    /**
     *
     * @param beerName String Attribute
     * @return Beer object
     */
    public Beer removeBeer(String beerName) {

        Beer a = null;

        for (int i = 0; i < beerList.size(); i++) {
            if (beerList.get(i).getBeerName().equals(beerName)) {
                a = beerList.get(i);
                beerList.remove(i);
            }
        }//end of loop

        return a;
    }//end of removeBeer Method

    /**
     *
     * @return ArrayList
     */
    public ArrayList<Beer> getStrongBeers() {
        ArrayList<Beer> b = new ArrayList<Beer>();
        for (int i = 0; i < beerList.size(); i++) {
            boolean a = beerList.get(i).isLightBeer();
            if (a == false) {
                b.add(beerList.get(i));
            }

        }//end of loop

        return b;
    }//end of getStrongBeer method

    /**
     *
     * @return ArrayList
     */
    public ArrayList<Beer> getLightBeers() {
        ArrayList<Beer> b = new ArrayList<Beer>();
        for (int i = 0; i < beerList.size(); i++) {
            boolean a = beerList.get(i).isLightBeer();
            if (a == true) {
                b.add(beerList.get(i));
            }

        }//end of loop

        return b;
    }//end of getLightBeer method

    /**
     *
     * @param beerName String Attribute
     * @return Integer a
     */
    public int getIndexinList(String beerName) {
        int a = 0;
        for (int i = 0; i < beerList.size(); i++) {
            if (beerName.equals(beerList.get(i).getBeerName())) {
                a = i;
            } else {
                a = -1;
            }

        }//end for loop

        return a;
    } //end of getIndexinList method

    @Override
    public String toString() {

        String a = (retailerName + "\r\n");
        String b = (address + "\r\n");
        String c = ("*****Beers List*****\r\n");
        String d = ("********************\r\n");
        String e = "";
        String f = "";
        for (int i = 0; i < beerList.size() - 1; i++) {
            e = e + beerList.get(i).toString() + "\r--------------------\n";

        }//end of for loop;

        e = e + beerList.get(beerList.size() - 1).toString();
        String g = ("********************\r\n");

        return a + b + c + d + e + g;
    }//end of toString Method

}//end of class
