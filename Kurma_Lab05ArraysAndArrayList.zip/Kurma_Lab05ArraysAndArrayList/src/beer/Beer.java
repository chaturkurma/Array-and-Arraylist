/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beer;

/**
 *
 * @author Chatur Veda Vyas Kurma;
 */
public class Beer 
{
    //private instance variable

    private String beerName;
    private String beerType;
    private String beerStyle;
    private double abv;
    private int[] availablePackages = new int[10];

    //constructor
    /**
     *
     * @param beerName String Attribute
     * @param beerType String Attribute
     * @param beerStyle String Attribute
     * @param abv double Attribute
     * @param availablePackages Integer Array
     */
    public Beer(String beerName, String beerType, String beerStyle, double abv, int[] availablePackages) {
        this.beerName = beerName;
        this.beerType = beerType;
        this.beerStyle = beerStyle;
        this.abv = abv;
        this.availablePackages = availablePackages;
    }//end of constructor

    //getter methods
    /**
     *
     * @return String beerName
     */
    public String getBeerName() {
        return beerName;
    }

    /**
     *
     * @return String beerType
     */
    public String getBeerType() {
        return beerType;
    }

    /**
     *
     * @return String beerStyle
     */
    public String getBeerStyle() {
        return beerStyle;
    }

    /**
     *
     * @return double abv
     */
    public double getAbv() {
        return abv;
    }

    /**
     *
     * @return IntegerArray availablePackage
     */
    public int[] getAvailablePackages() {
        return availablePackages;
    }

    //end of getter methods
    /**
     *
     * @return boolean Attribute
     */
    public boolean isLightBeer() {
        boolean a = false;
        if (abv <= 4.0) {
            a = true;
        }

        return a;
    }//end of method isLightBeer

    @Override
    public String toString() {
        String a = ("Beer Name: " + beerName + "\r\n");
        String b = ("Beer Type: " + beerType + ", Beer Style: " + beerStyle + "\r\n");
        String c = ("abv: " + abv + "%\r\n");
        String d = ("Available in packs of: ");
        String e = "";
        for (int i = 0; i < (availablePackages.length) - 1; i++) {
            e = e + (availablePackages[i] + ", ");
        }
        String f = (availablePackages[(availablePackages.length) - 1] + ".\r\n");

        return a + b + c + d + e + f;
    }//end of toString method
}//end of class
